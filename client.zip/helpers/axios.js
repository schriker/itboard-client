import axios from 'axios'

const api = axios.create({
  baseURL: process.env.NODE_ENV === 'development' ? 'http://localhost:8080/' : 'http://itboard-env.34gzgbdiyd.us-east-2.elasticbeanstalk.com/',
  withCredentials: true
})

export default api